# Magento2_Afterpay
Afterpay Payment Method for Magento 2
