<?php


namespace Mycompany\Uba\Model\Payment;

class Cod_for_schemes extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = "cod_for_schemes";
    protected $_isOffline = true;

    public function isAvailable(
        \Magento\Quote\Api\Data\CartInterface $quote = null
    ) {
        return parent::isAvailable($quote);
    }
}
