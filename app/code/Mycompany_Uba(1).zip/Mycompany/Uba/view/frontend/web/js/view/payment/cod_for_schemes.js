define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'cod_for_schemes',
                component: 'Mycompany_Uba/js/view/payment/method-renderer/cod_for_schemes-method'
            }
        );
        return Component.extend({});
    }
);