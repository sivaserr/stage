<?php


namespace Payment\Scod\Model\Payment;

class Cash_On_Delivery extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = "cash_on_delivery";
    protected $_isOffline = true;

    public function isAvailable(
        \Magento\Quote\Api\Data\CartInterface $quote = null
    ) {
        return parent::isAvailable($quote);
    }
}
