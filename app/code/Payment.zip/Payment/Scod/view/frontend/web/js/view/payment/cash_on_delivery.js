define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'cash_on_delivery',
                component: 'Payment_Scod/js/view/payment/method-renderer/cash_on_delivery-method'
            }
        );
        return Component.extend({});
    }
);